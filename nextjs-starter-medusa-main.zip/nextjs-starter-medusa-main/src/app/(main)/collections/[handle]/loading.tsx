import SkeletonCollectionPage from "@modules/skeletons/templates/skeleton-collection-page"

export default function Loading() {
  return <SkeletonCollectionPage />
}
