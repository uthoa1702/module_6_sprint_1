export const IS_BROWSER = typeof window !== "undefined"
